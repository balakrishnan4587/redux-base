# Setting up Webpack, Babel and React from scratch



bootstrap not working

Install dependencies

```
npm install
```

To start run

```
npm run dev
```
